----------------------------------------------------------------
-- Cr�ation d'un jeu de donn�es
----------------------------------------------------------------
-- Ce script fournit un jeu de donn�es permettant de remplir les tables de la base.
-- On lance une transaction pour s�curiser l'ex�cution du script.
-- Si par exemple une valeur a �t� mal rentr�e dans une des tables, on utilisera un rollback.
-- Sinon, on validera la transaction avec un commit. 
-- Un commit et un rollback sont disponibles en commentaire � la fin de ce script.


----------------------------------------------------------------
-- Insertion de valeurs dans la table Metier
----------------------------------------------------------------

begin tran

insert jo.Metier values (1, 'ANA'), (2, 'CDP'), (3, 'DEV'), (4, 'DES'), (5, 'TES')

-- On v�rifie l'insertion de nos valeurs.
-- select * from jo.Metier


----------------------------------------------------------------
-- Insertion de valeurs dans la table Activite
----------------------------------------------------------------

insert jo.Activite values (1, 'DBE'), (2, 'ARF'), (3, 'ANF'), (4, 'DES'), (5, 'INF'), (6, 'ART'),
						  (7, 'ANT'), (8, 'DEV'), (9, 'RPT'), (10, 'TES'), (11, 'GDP')

--On v�rifie l'insertion de nos valeurs.				  
--select * from jo.Activite


----------------------------------------------------------------
-- Insertion de valeurs dans la table ActiviteMetier
----------------------------------------------------------------

-- On associe � un m�tier plusieurs activit�s.

insert jo.ActiviteMetier values (1, 1), (1, 2), (1, 3),
								(2, 2), (2, 3), (2, 6), (2, 10), (2, 11),
								(3, 3), (3, 6), (3, 7), (3, 8), (3, 10),
								(4, 3), (4, 4), (4, 5),
								(5, 9), (5, 10)

-- On v�rifie l'insertion de nos valeurs.	
-- select * from jo.ActiviteMetier


----------------------------------------------------------------
-- Insertion de valeurs dans la table Filiere
----------------------------------------------------------------

insert jo.Filiere values (1, 'BIOH'), (2, 'BIOA'), (3, 'BIOV')

-- On v�rifie l'insertion de nos valeurs.
-- select * from jo.Filiere


----------------------------------------------------------------
-- Insertion de valeurs dans la table Service
----------------------------------------------------------------

insert jo.Service values (1, 'MKT'), (2, 'DEV'), (3, 'TEST'), (4, 'SL')

-- On v�rifie l'insertion de nos valeurs	
-- select * from jo.Service


----------------------------------------------------------------
-- Insertion de valeurs dans la table Equipe
----------------------------------------------------------------

insert jo.Equipe values (1, 2, 2, 'Team 1'), (2, 2, 3, 'Team 2'), (3, 3, 1, 'Team 3'), (4, 1, 4, 'Team 4')

-- On v�rifie l'insertion de nos valeurs.
-- select * from jo.Equipe


----------------------------------------------------------------
-- Insertion de valeurs dans la table Salarie
----------------------------------------------------------------

insert jo.Salarie values ('BNORMAND', 1, null, 2, 'NORMAND', 'Balthazar'),
						 ('RFISHER', 1, 'BNORMAND', 3, 'FISHER', 'Raymond'), 
					     ('LBUTLER', 1, 'BNORMAND', 3, 'BUTLER', 'Lucien') 
		     
-- On v�rifie l'insertion de nos valeurs.					  
-- select * from jo.Salarie


----------------------------------------------------------------
-- Insertion de valeurs dans la table Logiciel
----------------------------------------------------------------

insert jo.Logiciel values (1, 2, 'Genomica'), (2, 3, 'Ga�a')

-- On v�rifie l'insertion de nos valeurs.	
-- select * from jo.Logiciel


----------------------------------------------------------------
-- Insertion de valeurs dans la table Version
----------------------------------------------------------------

insert jo.Version values ('1.00', 2017, '2016-01-02', '2017-01-08', '2017-01-25', 1),
						 ('2.00', 2018, '2016-12-28', '2018-01-06', null, 1),
						 ('1.00', 2015, '2014-01-02', '2016-01-02', '2016-02-15', 2)

-- On v�rifie l'insertion de nos valeurs.					 
-- select * from jo.Version


----------------------------------------------------------------
-- Insertion de valeurs dans la table Release
----------------------------------------------------------------
-- /!\ Attention, l'Id est en Auto-Incr�ment.

insert jo.Release values ('2016-01-05', '1.00', 1), ('2016-01-01', '1.00', 2)

-- On v�rifie l'insertion de nos valeurs.
-- select * from jo.Release


----------------------------------------------------------------
-- Insertion de valeurs dans la table Module
----------------------------------------------------------------

insert jo.Module values (1, 'SEQUENCAGE', 1, null), (2, 'POLYMORPHISME', 1 , null), 
						(3, 'VAR_ALLELE', 1 , null), (4, 'MARQUAGE', 1, 1)  
	
-- On v�rifie l'insertion de nos valeurs.						
-- select * from jo.Module


----------------------------------------------------------------
--Insertion de valeurs dans la table Tache
----------------------------------------------------------------
-- /!\ Attention, l'Id est en Auto-Incr�ment.

insert jo.Tache values ('Tache 1', 'Libell� 1', 32),
					   ('Tache 2', 'Libell� 2', 20)

-- On v�rifie l'insertion de nos valeurs.	
-- select * from jo.Tache


----------------------------------------------------------------
-- Insertion de valeurs dans la table TacheAnnexe
----------------------------------------------------------------

insert jo.TacheAnnexe values (2)

-- On v�rifie l'insertion de nos valeurs.	
-- select * from jo.TacheAnnexe


----------------------------------------------------------------
-- Insertion de valeurs dans la table TacheProduction
----------------------------------------------------------------

insert jo.TacheProduction values (1, 40)

-- On v�rifie l'insertion de nos valeurs.	
-- select * from jo.TacheProduction


----------------------------------------------------------------
-- Insertion de valeurs dans la table HistoriqueTache
----------------------------------------------------------------

insert jo.HistoriqueTache values (1, GETDATE(), 5, 1, 'RFISHER', 1, 1, 1, '1.00', 2) 

-- On v�rifie l'insertion de nos valeurs.	
-- select * from jo.HistoriqueTache


----------------------------------------------------------------
-- Validation de la transaction (commit) ou annulation (rollback)
----------------------------------------------------------------
-- rollback
-- commit
