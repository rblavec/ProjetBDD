----------------------------------------------------------------
-- Cr�ation d'une t�che de production et d'une t�che annexe.
----------------------------------------------------------------
-- On cr�e des proc�dures pour g�n�rer les t�che de production et les t�ches annexes.
-- Pour cela nous devons d'abord cr�er des t�ches dans la table Tache.

-- Proc�dure cr�ant une t�che
create procedure usp_CreationTache @Libelle nvarchar(30), @Description nvarchar(100), @DureeEstim�e int
as
begin
	insert jo.Tache values (@Libelle, @Description, @DureeEstim�e)
end
go

-- Proc�dure cr�ant une t�che de production
create procedure usp_CreationTacheProd @IdTache int, @DureePrevue int
as
begin
	insert jo.TacheProduction values (@IdTache, @DureePrevue)
end
go

-- Proc�dure cr�ant une t�che annexe
create procedure usp_CreationTacheAnx @IdTache int
as
begin
	insert jo.TacheAnnexe values (@IdTache)
end
go


-- On teste la cr�ation d'une t�che de production.
begin tran
exec usp_CreationTache 'Tache 3', null, 50
exec usp_CreationTacheProd 3, 40

select * from jo.Tache
select * from jo.TacheProduction

--commit

-- On teste la cr�ation d'une t�che annexe.
begin tran
exec usp_CreationTache 'Tache 4', 'Formation initiale', 10
exec usp_CreationTacheAnx 3

select * from jo.Tache
select * from jo.TacheAnnexe

--commit


----------------------------------------------------------------
-- Saisie du temps journalier sur une t�che
----------------------------------------------------------------
-- On cr�e un HistoriqueTache en v�rifiant au pr�alable que le temps total saisi 
-- pour une journ�e ne d�passe pas 8 heures pour un salari� donn�.
-- Dans le cas contraire, un message d'erreur explicite est envoy� � l'utilisateur.

-- Cr�ation des messages d'erreur

exec sp_addmessage @msgnum = 50001, @severity = 12,
	@msgText = 'The total daily time must not exceed 8 hours !',
	@lang='us_english',
	@replace = 'replace'

exec sp_addmessage @msgnum = 50001, @severity = 12,
	@msgText = 'Le temps total journalier ne doit pas d�passer 8 heures !',
	@lang='French',
	@replace = 'replace'
	
-- On pr�f�re les messages en fran�ais.
set language 'French'

-- Cr�ation d'un HistoriqueTache via une proc�dure.
-- On v�rifie la condition de dur�e maximale par jour dans la proc�dure.

create procedure usp_NewHistoriqueTache @Id int, @DateJour date, @HeuresJour int, @Tx real, @IdSal nvarchar(10),
										@NumTache int, @IdAct int, @IdMod int, @Vers nvarchar(10), @log int
as
begin
	-- On compte le nombre d'heures d�j� rentr� pour la journ�e courante
	-- S'il n'y a pas de donn�es correspondantes, l'instruction isnull permet d'assigner la valeur 0 � @res.
	declare @res int
	set @res = isnull((select SUM(NbrHeuresParJour)
	from jo.HistoriqueTache
	where DateDuJour = @DateJour and Salarie_Login = @IdSal), 0)
			
	-- On v�rifie que la dur�e journali�re r�glementaire n'est pas d�pass�e.
	-- Si c'est le cas on l�ve une erreur explicite.			
	if (@res + @HeuresJour) > 8
		begin
			RAISERROR(50001, 12, 1)
			return
		end
	insert jo.HistoriqueTache values (@Id, @DateJour, @HeuresJour, @Tx, @IdSal,
									  @NumTache, @IdAct, @IdMod, @Vers, @log)
end
go

drop procedure usp_NewHistoriqueTache

-- Test de la cr�ation d'un HistoriqueTache

-- Premier test en mode esclave 15 heures par jour en choisissant une journ�e "vide".
begin tran
exec usp_NewHistoriqueTache 2, '2017-04-19' , 15, 1, 'LBUTLER', 1, 1, 1, '2.00', 1

-- Deuxi�me test avec une tache durant 4 heures
begin tran
exec usp_NewHistoriqueTache 3, '2017-04-20' , 4, 1, 'LBUTLER', 1, 1, 1, '2.00', 1

-- Troisi�me test avec une tache durant 6 heures pour la m�me journ�e.
begin tran
exec usp_NewHistoriqueTache 4, '2017-04-20' , 6, 1, 'LBUTLER', 1, 1, 1, '2.00', 1

-- rollback
-- commit

-- V�rificatin du contenu de la table
select * from jo.HistoriqueTache


---------------------------------------------------------------------------
-- Remplissage des listes d�roulantes des fen�tres de saisie de temps.
---------------------------------------------------------------------------
-- Pour cela, on construit une vue qui nous permettra de r�cup�rer les informations n�cessaires
-- � afficher dans les menus d�roulants.
-- On cr�e une fonction pour chaque menu d�roulant. Les fonctions retournent une table de cha�ne correspondant
-- aux informations souhait�es � afficher dans le menu d�roulant concern�.

-- Cr�ation de la vue

create view vwAffichageMenu as 
	(select l.NomLogiciel, v.Numero, m.Libelle [Libelle module]
	from jo.HistoriqueTache h
	inner join jo.Module m on m.CodeModule = h.Module_CodeModule
	right outer join jo.Logiciel l on l.Code = m.Logiciel_Code
	inner join jo."Version" v on v.Logiciel_Code = l.Code
	)
	
-- drop view vwAffichageMenu

select * from vwAffichageMenu

-- Fonction pour le menu logiciel
-- Affiche tous les logiciels disponibles dans la base de donn�es.
		
drop function ufn_MenuDeroulantLogiciel

create function ufn_MenuDeroulantLogiciel()
returns @TableId table
(
	NomLogiciel nvarchar (40) 	
)
as
begin
	insert @TableId
	select distinct vw.NomLogiciel
	from vwAffichageMenu vw	
	return
end
go	

-- Test de la fonction.
select * from ufn_MenuDeroulantLogiciel ()

-- Fonction pour le menu Version
-- Affiche les diff�rentes versions pour un logiciel donn� entr� en param�tre.

drop function ufn_MenuDeroulantVersion

create function ufn_MenuDeroulantVersion(@NomLogiciel nvarchar (30))
returns @TableId table
(
	NumVersion nvarchar (10) 	
)
as
begin
	insert @TableId
	select distinct vw.Numero
	from vwAffichageMenu vw	
	where vw.NomLogiciel = @NomLogiciel
	return
end
go	

-- Test de la fonction avec les deux logiciels entr�s dans la base de donn�es.
select * from ufn_MenuDeroulantVersion ('Ga�a')
select * from ufn_MenuDeroulantVersion ('Genomica')


-- Fonction pour le menu Module
-- Affiche les diff�rents modules pour un logiciel donn� entr� en param�tre.

drop function ufn_MenuDeroulantModule

create function ufn_MenuDeroulantModule(@NomLogiciel nvarchar (30))
returns @TableId table
(
	LibelModule nvarchar (100) 	
)
as
begin
	insert @TableId
	select distinct vw.[Libelle module]
	from vwAffichageMenu vw	
	where vw.NomLogiciel = @NomLogiciel
	return
	
end
go	

-- Test de la fonction avec les deux logiciels entr�s dans la base de donn�es.
select * from ufn_MenuDeroulantModule ('Genomica')
select * from ufn_MenuDeroulantModule ('Ga�a')


-- Fonction pour le menu Activit�
-- Affiche les diff�rentes Activit�s.
-- Pour cela, la vue cr��e pr�c�demment est inutile.

drop function ufn_MenuDeroulantActivite

create function ufn_MenuDeroulantActivite()
returns @TableId table
(
	NomActivite nvarchar (30) 	
)
as
begin
	insert @TableId
	select NomActivite
	from jo.Activite
	return
	
end
go	

-- Test de la fonction avec les deux logiciels entr�s dans la base de donn�es.
select * from ufn_MenuDeroulantActivite ()


-- Fonction pour le menu T�che
-- Affiche les diff�rentes T�che.
-- Pour cela, la vue cr��e pr�c�demment est inutile.

drop function ufn_MenuDeroulantTache

create function ufn_MenuDeroulantTache()
returns @TableId table
(
	NumTache integer,
	Descript nvarchar (100) 	
)
as
begin
	insert @TableId
	select NumeroTache, "Description"
	from jo.Tache
	return
	
end
go	

-- Test de la fonction avec les deux logiciels entr�s dans la base de donn�es.
select * from ufn_MenuDeroulantTache ()

---------------------------------------------------------------------------
-- Verification de la saisie des temps de travail des salari�s.
---------------------------------------------------------------------------
-- On aurait bien voulu cr�er une fonction renvoyant pour une date donn�es les heures de travail effectu�es
-- pour chaque employ�. Cette fonction aurait pris en param�tres d'entr�e l'ID du manager et la date.
-- Nous ne sommes pas parvenus � atteindre cet objectif. Une piste pourrait �tre li�e � un souci sur la structure
-- de notre base.
-- Faute de temps et ne sachant pas identifier clairement le probl�me, nous avons fait une fonction qui affiche
-- le nombre d'heures total par salari� et par jour, avec en param�tre d'entr�e l'Id du manager.

drop function ufn_Flicage

create function ufn_Flicage (@IdManager nvarchar (10))
returns @TableCoupables table 
(
	IdEmp nvarchar (10),
	NbrHeuresEffectif int,	
	DateTravail DATE
)
as
begin
	-- On r�cup�re la liste des salari�s qui d�pendent du manager.

	insert @TableCoupables
	select s."Login", isnull(SUM(NbrHeuresParJour),0), h.DateDuJour
	from jo.HistoriqueTache h
	right outer join jo.Salarie s on s."Login" = h.Salarie_Login
	where (Manager_Login = @IdManager)
	group by s."Login", h.DateDuJour
	return
end
go

-- Test de la fonction.
select * from ufn_Flicage ('BNORMAND') 


-------------------------------------------------------------------------------
-- Suppression de toutes les donn�es qui sont li�s � une version d'un logiciel
-------------------------------------------------------------------------------


--drop procedure usp_DeleteDeMasseVersion

create procedure usp_DeleteDeMasseVersion @NumeroVersion nvarchar (10), @CodeLogiciel int 
as 
begin
	delete h from jo.HistoriqueTache h
	where h.Version_Numero = @NumeroVersion and h.Version_Logiciel_Code = @CodeLogiciel

	delete r from jo.Release r 
	where r.Version_Logiciel_Code = @CodeLogiciel and r.Version_Numero = @NumeroVersion

	delete v from jo.Version v
	where v.Numero = @NumeroVersion and v.Logiciel_Code = @CodeLogiciel
end
go


-- Test de la fonction usp_DeleteDeMasseVersion.
begin tran
exec usp_DeleteDeMasseVersion '1.00', 2
rollback

-- V�rification de la suppression des donn�es.
select * from jo.HistoriqueTache
select * from jo.release
select * from jo."version"